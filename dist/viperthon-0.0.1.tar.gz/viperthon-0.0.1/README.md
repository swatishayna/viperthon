# viperthon
It will read different datafile and perform basic operation with just one click

## Installation
```pip install viperthon```

## Example
from viperthon import load
load("D:\data science\ineuron\ML\ML\class\Admission_Prediction.csv")



## License
© 2021 Swati Pandey

This repository is licensed under the MIT License.
See LICENSE for details.